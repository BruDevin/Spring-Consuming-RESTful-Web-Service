package com.example.consumerestservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumerestserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumerestserviceApplication.class, args);
	}

}
